create
    definer = root@localhost procedure PROC_DeleteBoughtInCart(IN in_customer_id int, IN in_size_id int, IN in_color_id int)
BEGIN
	DELETE FROM customer_product 
    where customer_id = in_customer_id 
			and color_id = in_color_id
            and size_id = in_size_id
            and status = true;
END;

