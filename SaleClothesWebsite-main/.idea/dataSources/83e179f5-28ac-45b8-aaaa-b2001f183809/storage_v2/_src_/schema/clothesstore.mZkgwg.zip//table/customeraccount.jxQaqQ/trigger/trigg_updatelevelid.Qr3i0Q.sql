create definer = root@localhost trigger TRIGG_UpdateLevelId
    before update
    on customeraccount
    for each row
BEGIN
  DECLARE Current_total DECIMAL(10,2);
  DECLARE Current_level INT;
  DECLARE done INT DEFAULT FALSE;
  DECLARE CursorLevel CURSOR FOR
    SELECT level_id, total_payment FROM levels;
    
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  
  -- LOOP THROUGH ALL AND COMPARE WITH EACH ITEM IN LEVELS TABLE
  OPEN CursorLevel;
  myloop: LOOP
    FETCH CursorLevel INTO Current_level, Current_total;
    IF done THEN
      LEAVE myloop;
    END IF;
    
    IF new.total_payment >= Current_total THEN
      set new.level_id = Current_level;
    END IF;
  END LOOP;
  CLOSE CursorLevel;
END;

