create definer = root@localhost trigger TRIGG_UpdateCompleteDate
    before update
    on orders
    for each row
BEGIN
    
    -- if new.isConfirmed = 1 mean that order has been confirmed then set status to 1 (which is shipping)
    -- if new.isConfirmed = 2 mean that order has been complete then check if user has the product then the order can complete
    if old.isConfirmed = 0 and new.isConfirmed = 1 then
		SET new.status = 1;
	
    elseif new.status = 2 and new.isCancel = false then
        SET new.dateComplete = current_timestamp();
    end if;
    
END;

