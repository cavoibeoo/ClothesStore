create definer = root@localhost trigger TRIGG_TotalPayment
    after update
    on orders
    for each row
BEGIN

	if new.status = 2 and new.isCancel != true then
		UPDATE customeraccount
		SET total_payment = total_payment + new.total_amount
        WHERE customer_id = new.customer_id;
	END IF;
END;

