create
    definer = root@localhost procedure PROC_DeleteBoughtInCart(IN in_customer_id int)
BEGIN
	DELETE FROM customer_product where customer_id = in_customer_id and status = true;
END;

