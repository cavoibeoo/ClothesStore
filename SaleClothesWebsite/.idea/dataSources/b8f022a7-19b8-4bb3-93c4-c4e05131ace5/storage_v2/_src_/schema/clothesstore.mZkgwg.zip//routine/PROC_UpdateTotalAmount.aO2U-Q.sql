create
    definer = root@localhost procedure PROC_UpdateTotalAmount(IN in_order_id int)
BEGIN
	
    DECLARE cal_total DECIMAL(10,2);
    SELECT SUM(total) INTO cal_total FROM order_products WHERE order_id = in_order_id;
    
    -- Define your update logic here
    UPDATE orders
    SET total_amount = cal_total - cal_total*discount
    WHERE order_id = in_order_id;
END;

