create definer = root@localhost trigger TRIGG_UpdateTotalAmount
    after insert
    on order_products
    for each row
BEGIN
	CALL PROC_UpdateTotalAmount(new.order_id);
END;

